# _Placoter_, une écriture montréalaise

_Placoter_ est une police de caractère née d’une démarche de cocréation en écriture, menée entre le laboratoire de recherche typographique interdisciplinaire TAO, à l’École de design, et des étudiant.e.s finissant.e.s du Baccalauréat en éducation préscolaire et en enseignement primaire de l’UQAM. Les participant.e.s ont procédé à un exercice de glanage photographique de lettres dans le contexte urbain montréalais, en réfléchissant à la façon dont ce travail ludique, inspiré de pratiques psychogéographiques, pourrait être proposé à de jeunes élèves, dans le cadre de l’apprentissage de la lecture, de l’écriture  et de l’éveil à l’observation attentive des éléments architecturaux propres à leur ville. Une série d’ateliers consécutifs a permis la sélection des lettres, ainsi que la rédaction collective de cet abécédaire montréalais à presque 100 mains, qui se pose en conversation interdisciplinaire entre deux approches de l’écriture : l’une comme forme, et l’autre comme contenu. Ces formes-lettres ont ensuite été vectorisées, mises en contexte graphiquement dans cette publication-pangramme, et déclinées sous la forme d’une police de caractère. 

Accessible au public et libre de droits (licence creative commons CC-BY, utilisation libre avec attribution), elle peut être téléchargée ici :
[www.placoter.org](www.placoter.org)

**Design, typographie, conception, édition :**
- Prof. Amandine Alessandra
- Mark Anthony Aguirre-Oliva (auxiliaire de recherche)
- Carolina Béa (auxiliaire de recherche)
- Laboratoire TAO (TAO est un laboratoire de recherche et création offrant un contexte d’expérimentation pour la typographie, la photographie et l’édition. Les projets interdisciplinaires TAO permettent diverses formes de collaboration entre étudiant.es et professeur.es).

**Web : **
- Jérôme Rigaud
- Mark Anthony Aguirre-Oliva 


**Ateliers d’écriture :**
- Prof. Amandine Alessandra (École de design, UQAM)
- Prof. Ophélie Tremblay (Département de didactique des langues, UQAM)

**Collecte et choix des images-lettres,  corédaction par les étudiant.e.s du cours DDM4101 — Approche expérientielle, projets pédagogiques et ressources du milieu**, profil d’approfondissement « Littérature et créativité » (Département de didactique, UQAM)
- Mauï Auger
- Audrey Beaudoin
- Jean-François Beaudet
- Tricia Bédard-Goyette
- Wiem Ben Gaied Hassine
- Karyne Bernier
- Maude Bergeron
- Pierre-Luc Boivin
- Meriem Boudeffa
- Jade Breton
- Charlie Brière-Couture
- Catherine Buteau
- Malory Chassé
- Valérie Desjardins
- Noémie Dumas
- Paramita Faucher-Nachampassak
- Claudia Gay
- Camélia Grandchamp-Lapointe
- Gabrielle Hébert
- Sarah Hénault
- Eugénie Labrèche
- Tommy Leduc
- Maude Lefrançois
- Dana Lord-Beaudin
- Annabelle Meloche
- Laurie Mooijekind
- Marie-Pier Morissette
- Rosalie Morin-Lévesque
- Fedja Nicolas-Joseph
- Édith Ouellet
- Catherine Perron
- Roxanne Perreault
- Débora Poirier
- Laurence Potvin-Beaudoin
- Chloé Quinn
- Estelle Rabeuf
- Émilie Richard
- Catherine Rioux Taché
- Sabrina Sadeg
- Jasmine Sylvestre
- Millie Thivierge
- Maude Vadeboncoeur
- Raphaëlle Vermette

<br>
- Prof. Amandine Alessandra
- Prof. Ophélie Tremblay 
- Mark Anthony Aguirre-Oliva

D’après un projet originellement conçu avec l’architecte Rute Nieto Ferreira, pour notre maison d’édition Tower Block Books, Londres, Royaume-Uni.

La réalisation de ce projet a été possible grâce à une subvention du Programme d’aide financière à la recherche et à la création (PAFARC) de l’Université du Québec à Montréal dans le contexte de la recherche d’Amandine Alessandra sur L’expérience lisible : L’être ensemble.



